<div id="top"></div>
Projet Wireframe sur table interactive
======================================

Dans le cadre l'enseignement "NF28 : Ingénierie des Systèmes Interactifs" à l'Université Technologique de Compiègne nous avons été amenés à développer une application. Notre choix s'est porté sur une technologie multi-touch et notamment sur un sujet pour la table interactive mise à disposition par l'université.

Sommaire
========
* <a href="#groupe">Les membres du groupe</a>
* <a href="#sujet">Présentation du sujet</a>


<div id="groupe"></div>
Les membres du groupe
=====================
* Serge Farny, GI04
* Yi Chen, GI04
* Clément Boissière, GI04
* Joseph Silvestre, GI04

<a href="#top">Retour en haut</a>

<div id="sujet"></div>
Le sujet : une application de prototypage "Wireframe"
=====================================================
Nous avons proposé notre projet sujet à l'équipe enseignantes : une application de prototypage de maquette en fils de fer (Wireframe).
Le but est de permettre aux concepteurs d'interface de penser l'ergonomie globale et l'enchaînement des écrans. Ainsi, ils pourront à la fois discuter de leur travail au sein de leur équipe et le présenter au client très visuellement.

<a href="#top">Retour en haut</a>

<div id="lesite"></div>
Ce que vous trouverez sur ce site
=================================
Vous trouverez sur ce site l'ensemble des documents relatifs au projet : les rapports et le code source.

<a href="#top">Retour en haut</a>
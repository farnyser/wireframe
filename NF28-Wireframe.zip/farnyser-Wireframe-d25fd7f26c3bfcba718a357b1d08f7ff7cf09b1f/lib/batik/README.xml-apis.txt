This distribution includes xml-apis.jar from the XML Commons External
1.3.04 binary distribution, which can also be obtained from:

  http://xml.apache.org/mirrors.cgi

Source code is available from the XML Commons web site:

  http://xml.apache.org/commons/

xml-apis.jar contains:

  - DOM Level 2 Events
  - DOM Level 2 HTML
  - DOM Level 2 Style
  - DOM Level 2 Traversal and Range
  - DOM Level 2 Views
  - DOM Level 3 Core
  - DOM Level 3 Load and Save
  - DOM Level 3 XPath
  - JAXP 1.3 (JSR 206)
  - SAX

All DOM code is licensed under the W3C Software License, and DOM documentation
under the W3C Document License.  See LICENSE.dom-software.txt and
LICENSE.dom-documentation.txt.

The JAXP 1.3 code is licensed under the Apache Software License 2.0, which is
in the LICENSE in the root directory of this distribution.

SAX is public domain.  See LICENSE.sax.txt.

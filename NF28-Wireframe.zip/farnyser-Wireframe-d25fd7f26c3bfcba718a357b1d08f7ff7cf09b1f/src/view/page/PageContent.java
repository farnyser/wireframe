package view.page;

import org.mt4j.components.visibleComponents.shapes.MTRectangle;

import processing.core.PApplet;

public class PageContent extends MTRectangle {

	public PageContent(PApplet pApplet, float x, float y, float width, float height) 
	{
		super(pApplet, x, y, width, height);
	}

}

package model.widget;

public class PersonalWidget extends Widget 
{
	private static final long serialVersionUID = 3489225040819315015L;
	protected String texture;
	
	public String getTexture() 
	{
		return texture;
	}
	public void setTexture(String texture) 
	{
		this.texture = texture;
	}
}

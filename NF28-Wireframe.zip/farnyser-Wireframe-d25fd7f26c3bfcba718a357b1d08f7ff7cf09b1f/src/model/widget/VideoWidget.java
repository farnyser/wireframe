package model.widget;

public class VideoWidget extends Widget 
{
	private static final long serialVersionUID = 3038356560859671957L;
}

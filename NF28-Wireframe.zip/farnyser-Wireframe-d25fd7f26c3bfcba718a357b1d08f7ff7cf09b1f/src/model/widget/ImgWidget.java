package model.widget;

public class ImgWidget extends Widget 
{
	private static final long serialVersionUID = 3191588821403980539L;
}
